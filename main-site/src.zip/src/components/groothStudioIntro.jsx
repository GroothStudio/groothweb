import { BorderBox } from "./box";
import Ikan from "../assets/Group 14.svg";
import Logo from "../assets/logo.svg";

export const GroothStudioIntro = () => {
  return (
    <div className="w-[100vw] h-[100vh] m-0 p-auto flex items-center justify-center">

      <BorderBox className="w-[93%] h-[93vh] relative self-center">
        <img src={Logo} alt="" className="absolute top-2 left-2" />
        <div className="h-[62%] max-md:h-[80%] text-center flex flex-col max-md:gap-[60px] items-center justify-center relative">
          <img src={Ikan} alt="Grooth Studio" className="max-md:w-[100vw]"/>
          <p className="mt-8 text-left text-base sm:text-lg md:text-xl lg:text-2xl leading-relaxed font-normal max-md:w-[86%]">
            Grooth Studio is an indie game development group founded on April
            19, 2024. We focus on creating and developing fun and innovative 2D
            games, aiming to offer players a unique and enjoyable experience.
            Our team consists of talented and dedicated members, each with
            specific skills, ensuring high quality game production.
          </p>
        </div>
        <p className="text-[20px] absolute right-[2%] bottom-[2%] font-bold max-md:text-[13px]">
          ©{new Date().getFullYear()} Grooth Studio. All rights reserved
        </p>
      </BorderBox>
    </div>
  );
};
