import { BorderBox } from "./box";
import AnimatedContent from '../AnimatedContent/AnimatedContent'

const anggota2 = () => {
  const a = [
    {
      nama: "Elbert",
      jabatan: "Unity Developer",
      keterangan:
        "Elbert brings the game to life—literally. As the Unity developer, he transforms design and code into an interactive experience that players can touch, see, and feel. He crafts the gameplay mechanics, visual effects, and player controls that define how the world behaves and responds. His expertise turns ideas into a fully playable reality.",
      link: "https://boltbert.netlify.app/",
    },
    {
      nama: "Glenndovin",
      jabatan: "Designer",
      keterangan:
        "Glenndovin is the visionary who shapes the world’s aesthetics. From UI layout to environment concept art, he ensures that everything not only looks beautiful but also feels intuitive. His designs create the first impression and the lasting emotional tone of the game, guiding players visually and emotionally through the experience.",
      link: "https://portovin.netlify.app",
    },
    {
      nama: "Gabriel",
      jabatan: "Music Engineer",
      keterangan:
        "Gabriel is the soul of the project. Through melodies and soundscapes, he evokes emotion, tension, and wonder. His compositions breathe life into every scene—from epic battles to quiet reflection. The world wouldn’t feel the same without his music guiding the player’s heart through every moment.",
      link: "",
    },
    {
      nama: "Joseph",
      jabatan: "Frontend Web Developer",
      keterangan:
        "Joseph is the mastermind behind this website. He designed the platform that serves as a bridge between the development team and the players, ensuring seamless communication. Additionally, he writes the lore that immerses players deeply into the world he has created, weaving stories that enhance their experience and connection to the game.",
      link: "",
    },
    {
      nama: "Timothy",
      jabatan: "Backend Web Developer",
      keterangan:
        "Timothy is the silent force powering everything behind the scenes. He builds and maintains the core systems that keep the game running smoothly, ensuring stability, performance, and security. From user authentication to database optimization, his code forms the invisible backbone of the entire experience. Without his work, none of it would function as intended.",
      link: "",
    },
  ];
  return a.map((anggota, index) => (
          <AnimatedContent

        distance={130}

        direction="vertikal"

        reverse={false}

        duration={1.2}

        ease="bounce.out"

        initialOpacity={0}

        animateOpacity

        scale={1.1}

        threshold={0.2}

        delay={0.2}

      >
    <BorderBox
      key={index}
      className="w-[45.5vw] max-md:w-[44vw] h-[60vh] max-md:h-[50vh] lg:w-[45.5vw] lg:h-[73vh] m-4 flex flex-col p-[1vw]"
    >
      <div className="flex flex-col h-[90%] justify-around">
        <div className="top-20 w-[39.5vw] flex flex-col gap-[40px]">
          <div className="text-left self-start flex flex-row items-center justify-center gap-[20px]">
            <div className="w-[90px] h-[90px] max-md:w-[44px] max-md:h-[44px] rounded-[100px] bg-[#3A86FE]"></div>
            <div className="flex flex-col">
              <h2 className="text-[2.89vw] max-md:text-[24px] font-bold">{anggota.nama}</h2>
              <h3 className="text-[1.93vw]">{anggota.jabatan}</h3>
            </div>
          </div>
          <p className="text-[1.2vw] max-md:text-[2vw] font-400 mt-2">{anggota.keterangan}</p>
        </div>
        <a href={anggota.link}>
          <button className="w-[39.5vw] h-[4.5vw] bg-[#3A86FE] rounded-[1.5vw] max-md:rounded-[1vw] max-md:h-[40px] text-[white] text-[24px] max-md:text-[4vw] cursor-pointer">
            Open Portofolio
          </button>
        </a>
      </div>
    </BorderBox></AnimatedContent>
  ));
};
export const Anggota = () => {
  return (
    <div className="max-w-[100vw] w-[100vw] h-fit m-0 p-auto flex flex-wrap">
      <h1 className="text-600 font-semibold text-[48px] font-poppins text-start self-start text-[#3A86FE] mb-[20px] pl-[3.5vw]">
        Our Member
      </h1>
      <div className="flex flex-wrap gap-[2vw] pt-[5vh] max-md:gap-[25px] max-md:gap-y-[30px] pb-[20vh] items-center justify-center">
        {anggota2()}
      </div>
    </div>
  );
};
