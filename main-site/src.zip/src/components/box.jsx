export const BorderBox = ({ children, className = "" }) => {
  return (
    <div
      className={`relative flex items-center justify-center border-2 border-[#3A86FE] text-[#3A86FE] p-6 ${className}`}
    >
      <div className="absolute top-[-0.5rem] left-[-0.8rem] w-6 h-4 bg-[#3A86FE]" />
      <div className="absolute top-[-0.5rem] right-[-0.8rem] w-6 h-4 bg-[#3A86FE]" />
      <div className="absolute bottom-[-0.5rem] left-[-0.8rem] w-6 h-4 bg-[#3A86FE]" />
      <div className="absolute bottom-[-0.5rem] right-[-0.8rem] w-6 h-4 bg-[#3A86FE]" />

      {children}
    </div>
  );
};
